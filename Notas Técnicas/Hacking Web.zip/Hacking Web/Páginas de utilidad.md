
### Generador de shells simples en varios lenguajes --> https://www.revshells.com/

### Guía de payloads y bypasses para vulnerabilidades web --> https://github.com/swisskyrepo/PayloadsAllTheThings

### Guía general de hacking con metodologías interesantes --> https://book.hacktricks.wiki/en/index.html

### Tool para hacer bypass a errores 403 --> https://github.com/iamj0ker/bypass-403

### Cheatsheet para sacar el tipo de template que usa una página --> https://cheatsheet.hackmanit.de/template-injection-table/
